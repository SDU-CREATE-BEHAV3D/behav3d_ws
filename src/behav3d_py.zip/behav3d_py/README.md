# TODO:

- [ ] refactor `image_processor` into `behav3d`.
- [ ] expand controller (`get_eef_pose()`, `get_eef_vel()`).
- [ ] debug `motion_visualizer.py` and expand w/`show_trail`, `show_ghost`, `show_targets`.
- [ ] implement `scan_trajectories` and `target_helpers`.

- [ ] I4.0 orientation (URDF/SRDF)
